package common;

import org.neo4j.graphdb.Label;

public enum LabelTypes implements Label {
	Classification, Paper, Author 
}